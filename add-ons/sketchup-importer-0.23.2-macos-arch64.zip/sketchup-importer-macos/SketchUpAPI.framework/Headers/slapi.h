// Copyright 2015 Trimble Inc., All rights reserved.
// This file is intended for public distribution.

/**
 * @file
 * @brief Deprecated, don't use.
 * @deprecated This file was left here for compatibility.
 *             Avoid using it in future projects if possible.
 */

// NOTE: This file is provided as a shim header to include common.h, which now
// contains the contents of the original slapi.h. This rename is due to the
// addition of the Layout API for consistency. This header is deprecated and
// will be removed in the future.

#include <SketchUpAPI/common.h>
