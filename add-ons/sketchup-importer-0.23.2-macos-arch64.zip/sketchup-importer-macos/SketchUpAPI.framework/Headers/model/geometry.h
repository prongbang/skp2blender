// Copyright 2013 Trimble Inc., All rights reserved.

/**
 * @file
 * @brief Deprecated, don't use.
 * @deprecated This file was left here for compatibility.
 *             Avoid using it in future projects if possible.
 */
#ifndef SKETCHUP_MODEL_GEOMETRY_H_
#define SKETCHUP_MODEL_GEOMETRY_H_

// This file was left here for compatibility. Avoid using it in future projects
// if possible.
#include <SketchUpAPI/geometry.h>
#include <SketchUpAPI/geometry/point3d.h>
#include <SketchUpAPI/geometry/bounding_box.h>
#include <SketchUpAPI/geometry/plane3d.h>
#include <SketchUpAPI/geometry/transformation.h>

#endif  // SKETCHUP_MODEL_GEOMETRY_H_
