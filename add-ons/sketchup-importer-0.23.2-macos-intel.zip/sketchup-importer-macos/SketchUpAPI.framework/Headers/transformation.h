// Copyright 2013 Trimble Inc., All rights reserved.

/**
 * @file
 * @brief Deprecated, don't use.
 * @deprecated This file was left here for compatibility.
 *             Avoid using it in future projects if possible.
 */
#ifndef SKETCHUP_TRANSFORMATION_H_
#define SKETCHUP_TRANSFORMATION_H_

// This file was left here for compatibility. Avoid using it in future projects
// if possible.
#include <SketchUpAPI/geometry.h>

#endif  // SKETCHUP_TRANSFORMATION_H_
